package com.ftp.topup.transfer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ftp.topup.model.Message;
import com.ftp.topup.model.Status;

public class TransferMptTopupService extends TransferMptTopupConstants {

	private static final Log log = LogFactory.getLog(TransferMptTopupService.class);

	public static Message doMptTopupProcess(String mobile, String charge)
			throws IOException, InterruptedException, JSONException {
        
		log.info("call doMptTopupProcess method.");
		// Get the available ports of ejoin multi-sim system
		List<String> portList = getAvaliablePorts();
		// Declare message object
		Message message = new Message();

		boolean flag = true;
		// Loop the current available ports
		forloop: for (String port : portList) {

			while (flag) {
				
				Status status = getCurrentEnableSIMStatus(port);
				String simNo = status.getPort();
				log.info("Current port : " + port + ", current sim : " + simNo);

				// Check the balance of current SIM(Port)
				Message msg = checkBalance(port);
				log.info("Balance check to current sim : " + simNo + " => " + msg.toString());

				// For pending state
				if (msg.getCode().equalsIgnoreCase("4")) {
					log.info("Port (" + port + ") is pending USSD exists.");
					continue forloop;
				}

				// For SIM is not registered state
				if (msg.getCode().equalsIgnoreCase("5")) {
					log.info(simNo + " is not registered.");
					message = lockSIM(simNo);
					TransferMptTopupDao.saveFtpEjoinSimStatus(simNo, 0, mobile, "0", "SIM is not registered.", "MPT");
					continue forloop;
				}

				String resp = msg.getResp();

				resp = resp.substring(33, 41);
				resp = resp.replace("K", "");
				resp = resp.replace("s", "");
				resp = resp.replace(",", "");
				resp = resp.replace("v", "");
				resp = resp.replace("a", "");
				resp = resp.replace("l", "");
				resp = resp.replace("i", "");

				// Get the balance of current SIM
				int bal = Integer.parseInt(resp.trim());
				int chargeBill = Integer.parseInt(charge);

				// Add commercial tax fee 0.0525% to transfer in customer bill
				// chargeBill += chargeBill * 0.06;
				chargeBill += chargeBill * 0.0525;

				if (bal >= chargeBill) {
					log.info("Requested topup bill " + chargeBill + " is enough and continue to topup porcess.");

					// Change english
					Message changeEngResp = changeEnglish(port);
					//log.info(changeEngResp.toString());
					if (changeEngResp.getCode().equals("0")) {
						// Topup bill
						message = topupMPT(mobile, charge, port);
						
						if (message.getResp().contains("send 1")) {
							log.info("Twice confirm! Wow!");
							message = topupConfirm(port);
						}
					} else {
						continue forloop;
					}

					// String topupMessageCode = message.getCode();
					String topupMessageResp = message.getResp();

					if (topupMessageResp.contains("limit of 5 balance")) {
						// If 5 time limits, lock SIM
						log.info(simNo + " has limit of 5 balance for today.");
						message = lockSIM(simNo);
						continue forloop;
					} else if (topupMessageResp.contains("your minimum usage needs to be 3000 Ks")) {
						// If sim card is invalid, lock SIM
						log.info(simNo + " 's minimum usage need to be 3000 Ks.");
						message = lockSIM(simNo);
						TransferMptTopupDao.saveFtpEjoinSimStatus(simNo, bal, mobile, "0", "Your minimum usage needs to be 3000 Ks to use this service", "MPT");
						continue forloop;
					} else {
						// E-topup system processing complete or success
						break forloop;
					}
					
				} else {
					log.info("Requested topup bill " + bal + " is not enough and continue to lock SIM : " + simNo);
					message = lockSIM(simNo);
					// Save log for balance not enough SIM
					TransferMptTopupDao.saveFtpEjoinSimStatus(simNo, bal, mobile, charge, "Not enough balance", "MPT");
					continue forloop;
				}
			}
		}
		return message;
	}

	private static List<String> getAvaliablePorts() throws InterruptedException, JSONException, IOException {
		String url = FTP_USSD_GATEWAY + "username=" + USER_NAME + "&password=" + PASSWORD;

		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();

		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		// create ObjectMapper instance
		ObjectMapper objectMapper = new ObjectMapper();
		
        log.info(response.toString());
		// convert json string to object
		Message msgTopupRequest = objectMapper.readValue(response.toString(), Message.class);
		
		log.info(msgTopupRequest.toString());

		String ports = msgTopupRequest.getPort();
		List<String> portList = preparePorts(ports);

		return portList;
	}

	private static List<String> preparePorts(String portString) {
		List<String> portList = new ArrayList();

		StringTokenizer st = new StringTokenizer(portString, ",");
		while (st.hasMoreTokens()) {
			String s = st.nextToken();
			if (s.contains("-")) {
				int _points = s.indexOf("-");
				int endPoint = s.length();

				int start = Integer.parseInt(s.substring(0, _points));
				int end = Integer.parseInt(s.substring((_points + 1), endPoint));

				for (int i = start; i <= end; i++) {
					portList.add(String.valueOf(i));
				}
			} else {
				portList.add(s);
			}
		}

		log.info("Avaliable ports : " + portList.toString());

		return portList;
	}

	/**
	 * Check the USSD balance for current port
	 * 
	 * @param port
	 * @return
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	private static Message checkBalance(String port) throws JsonParseException, JsonMappingException, IOException {

		String url = FTP_USSD_GATEWAY + "username=" + USER_NAME + "&password=" + PASSWORD + "&port=" + port
				+ "&ussd=*124%23";

		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();

		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		// Create ObjectMapper instance
		ObjectMapper objectMapper = new ObjectMapper();

		// Convert json string to object
		Message balanceMessage = objectMapper.readValue(response.toString(), Message.class);

		return balanceMessage;
	}

	public static Message topupMPT(String mobile, String charge, String port)
			throws InterruptedException, JSONException, IOException {

		String url = FTP_USSD_GATEWAY + "username=" + USER_NAME + "&password=" + PASSWORD + "&port=" + port
				+ "&ussd=*223*" + charge + "*" + mobile + "%23";

		log.info("Transfer MPT topup request url : " + url);

		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();

		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		Message msgTopupRequestConfirm = topupConfirm(port);

		return msgTopupRequestConfirm;
	}

	public static Message topupConfirm(String port) throws InterruptedException, JSONException, IOException {
		String url = FTP_USSD_GATEWAY + "username=" + USER_NAME + "&password=" + PASSWORD + "&port=" + port + "&ussd=1";

		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();

		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		// Create ObjectMapper instance
		ObjectMapper objectMapper = new ObjectMapper();

		// Convert json string to object
		Message msg = objectMapper.readValue(response.toString(), Message.class);

		return msg;
	}

	private static Status getCurrentEnableSIMStatus(String port) throws IOException, JSONException {
		String url = FTP_GOIP_GET_STATUS + "username=root&password=root&port=" + port;

		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();

		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		JSONObject jsonObj = new JSONObject(response.toString());

		JSONArray array = jsonObj.getJSONArray("status");

		// Create ObjectMapper instance
		ObjectMapper objectMapper = new ObjectMapper();

		List<Status> statusList = objectMapper.readValue(array.toString(),
				objectMapper.getTypeFactory().constructCollectionType(List.class, Status.class));

		Status status = statusList.get(0);

		return status;
	}

	/**
	 * Lock the current enable SIM
	 * 
	 * @param port
	 * @return
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	private static Message lockSIM(String simNo) throws JsonParseException, JsonMappingException, IOException {

		String url = FTP_GOIP_SEND_CMD + "username=" + USER_NAME + "&password=" + PASSWORD + "&port=" + simNo
				+ "&op=lock";

		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();

		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		// Create ObjectMapper instance
		ObjectMapper objectMapper = new ObjectMapper();

		// Convert json string to object
		Message msg = objectMapper.readValue(response.toString(), Message.class);

		return msg;
	}

	private static Message changeEnglish(String port) throws JsonParseException, JsonMappingException, IOException {

		String url = FTP_USSD_GATEWAY + "username=" + USER_NAME + "&password=" + PASSWORD + "&port=" + port
				+ "&ussd=*106*7*1%23";

		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();

		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		// Create ObjectMapper instance
		ObjectMapper objectMapper = new ObjectMapper();

		// Convert json string to object
		Message msg = objectMapper.readValue(response.toString(), Message.class);

		return msg;
	}
	
	public static void main(String[] args) throws JSONException, IOException, InterruptedException {
		getAvaliablePorts();
	}
}
