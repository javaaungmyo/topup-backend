package com.ftp.topup.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.ftp.topup.model.Transaction;
import com.ftp.topup.model.TransactionRequestBean;

public class CommonUtils {

	public static boolean saveTransaction(String phoneNo, String useCase, String topupType, double amount, double realAmount, double commissionRate, double balance, long userId) {

		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			double commisson_amount = amount-realAmount;
			
			connection = ConnectionManager.getConnection();
			String saveFtpEjoinSimStatusQuery = "INSERT INTO transactions(phone_no, use_case, topup_type, amount, real_amount, commission_rate, commission_amount, balance, user_id, created_date) "
					+ "VALUES(?,?,?,?,?,?,?,?,?,?)";

			preparedStatement = connection.prepareStatement(saveFtpEjoinSimStatusQuery);
			preparedStatement.setString(1, phoneNo);
			preparedStatement.setString(2, useCase);
			preparedStatement.setString(3, topupType);
			preparedStatement.setDouble(4, amount);
			preparedStatement.setDouble(5, realAmount);
			preparedStatement.setDouble(6, commissionRate);
			preparedStatement.setDouble(7, commisson_amount);
			preparedStatement.setDouble(8, balance);
			preparedStatement.setLong(9, userId);
			preparedStatement.setTimestamp(10, getCurrentDate());

			int i = preparedStatement.executeUpdate();

			if (i > 0) {
				return Boolean.TRUE;
			} else {
				return Boolean.FALSE;
			}

		} catch (Exception e) {

			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e1) {

				}
			}
			return Boolean.FALSE;
		}
	}
	
	public static List<Transaction> getTransactionList(TransactionRequestBean info) {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		List<Transaction> txns = new ArrayList<Transaction>();
		String sub_query = "";
		try {
			connection = ConnectionManager.getConnection();
			
			if(!info.getFromDate().equals("")){
				
				sub_query += " and DATE(created_date) >= '"+convertDateFormat(info.getFromDate())+"' ";
			}
			if(!info.getToDate().equals(""))
				sub_query += " and DATE(created_date) <=  '"+convertDateFormat(info.getToDate())+"' ";
				
			if(!info.getPhoneNo().equals(""))
				sub_query += " and phone_no = '"+info.getPhoneNo()+"' ";
			
			if(!info.getUsecase().equals("All"))
				sub_query += " and use_case = '"+info.getUsecase()+"' ";
			
			String sql = "select * from transactions where user_id = ? "+sub_query+" order by id desc";
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setLong(1, info.getUserId());

			ResultSet rs = preparedStatement.executeQuery();

			if (rs != null) {

				while (rs.next()) {
					Transaction txn = new Transaction();
					txn.setId(rs.getLong(1));
					txn.setPhoneNo(rs.getString(2));
					txn.setUsecase(rs.getString(3));
					txn.setTopupType(rs.getString(4));
					txn.setAmount(rs.getDouble(5));
					txn.setRealAmount(rs.getDouble(6));
					txn.setCommissionRate(rs.getDouble(7));
					txn.setCommissionAmount(rs.getDouble(8));
					txn.setBalance(rs.getDouble(9));
					txn.setUserId(rs.getLong(10));					
					txn.setCreatedDate(rs.getTimestamp(11));
					
					txns.add(txn);
				}
			}
			connection.close();

		} catch (Exception e) {

			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e1) {

				}
			}
		}

		return txns;
	}
	
	public static long getSva(long userId) {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		long sva = 0;

		try {

			connection = ConnectionManager.getConnection();
			String sql = "SELECT balance FROM user_sva where user_id = ?";
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setLong(1, userId);
			ResultSet result = preparedStatement.executeQuery();

			if (result != null) {
				if (result.next()) {
					sva = result.getLong(1);
				}				
			}

			connection.close();

		} catch (Exception e) {

			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e1) {

				}
			}
		}

		return sva;
	}

	private static Timestamp getCurrentDate() {
		java.util.Date today = new java.util.Date();
		return new Timestamp(today.getTime());
	}
	
	public static String convertDateFormat(String date){
		
		String [] d_slice = date.split("-");
		String d_date = d_slice[2]+"-"+d_slice[1]+"-"+d_slice[0];
		
		return d_date;
	}
	
	

}
