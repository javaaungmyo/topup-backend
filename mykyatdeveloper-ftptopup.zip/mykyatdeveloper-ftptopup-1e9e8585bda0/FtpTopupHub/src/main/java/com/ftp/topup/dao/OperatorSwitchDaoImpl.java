package com.ftp.topup.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.ftp.topup.model.OperatorSwitch;

@Repository("operatorSwitchDao")
public class OperatorSwitchDaoImpl extends AbstractDao<Integer, OperatorSwitch> implements OperatorSwitchDao {
	public List<OperatorSwitch> getAvailableTelco() {		
		Criteria crit = createEntityCriteria();
		crit.add(Restrictions.eq("status", 1));
		List<OperatorSwitch> operators = crit.list();
		return operators;
	}

	@Override
	public List<OperatorSwitch> getAllOperators() {
		// TODO Auto-generated method stub
		String hql = "select op from OperatorSwitch op";
		List<OperatorSwitch> operators = getSession().createQuery(hql).list();
		return operators;
	}
}
