package com.ftp.topup.transfer;

import java.io.IOException;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONException;

import com.ftp.topup.model.Message;
import com.ftp.topup.model.Status;

public class TransferMytelTopupService extends TransferMytelTopupConstants {

	private static final Log log = LogFactory.getLog(TransferMytelTopupService.class);
	
	protected static final String REMOVABLE_PORTS = "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24";

	public static Message doMytelTopupProcess(String mobile, String amount)
			throws IOException, InterruptedException, JSONException {
		
		boolean flag = true;
		Message message = new Message();
		
		// Get all available ports
		List<String> portList = TransferMytelTopupSupport.getAvaliablePorts();
		//log.info(mobile + ", all available ports : " + portList.toString());
		
		// Remove ports except Mytel ports
		TransferMytelTopupSupport.removePorts(portList, REMOVABLE_PORTS);
		//log.info(mobile + ", available ports after removing : " + portList.toString());
		
        // Loop the current available ports
		forloop: for (String port : portList) {

			while (flag) {
                
				// Get current SIM no.
				Status status = TransferMytelTopupSupport.getCurrentEnableSIMStatus(port);				
				String simNo = status.getPort();                
				// Check the balance of current SIM(Port)
				Message msg = TransferMytelTopupSupport.checkBalance(port);				
				//log.info(mobile + ", balance check of " + simNo + ", " + msg.toString());
				
				// For pending state
				if (msg.getCode().equalsIgnoreCase("4")) {
					log.info(mobile + ", " + port + " -> pending USSD exists.");
					continue forloop;
				}
				
				// For SIM not registered state
				if (msg.getCode().equalsIgnoreCase("5")) {
					//log.info(simNo + " is not registered.");
					message = TransferMytelTopupSupport.lockSIM(simNo);
					TransferMytelTopupDao.saveTransferMytelTopup(simNo, 0, mobile, "0", "SIM is not registered.", "Mytel");
					continue forloop;
				}

				String resp = msg.getResp();
				resp = TransferMytelTopupUtil.getAmount(resp);                
				// Get the balance of current SIM
				int bal = Integer.parseInt(resp.trim());
				int chargeBill = Integer.parseInt(amount);

				if (bal >= chargeBill) {
					
					//log.info("Require topup bill " + chargeBill + " is enough and continue to topup porcess.");
                    
                    message = TransferMytelTopupSupport.topup(mobile, amount, port);
					String topupMessageResp = message.getResp();
					
					System.out.println(mobile + " at port " + port + " topup final response : " + topupMessageResp);
					log.info(mobile + " at port " + port + " topup final response : " + topupMessageResp);

					if (topupMessageResp.contains("5 times")) {
						// If 5 time limits, lock SIM
						//log.info(simNo + " has limit of 5 balance for today.");
						message = TransferMytelTopupSupport.lockSIM(simNo);
						continue forloop;
					} else if (topupMessageResp.contains("your minimum usage needs to be 3000 Ks")){
						// If sim card is invalid, lock SIM
						//log.info(simNo + " 's minimum usage need to be 3000 Ks.");
						message = TransferMytelTopupSupport.lockSIM(simNo);
						TransferMytelTopupDao.saveTransferMytelTopup(simNo, bal, mobile, "0", "Your minimum usage needs to be 3000 Ks to use this service", "Mytel");
						continue forloop;
					} else {
						// E-topup system processing complete or success
						break forloop;
					}
				} else {
					//log.info("Required topup bill " + bal + " is not enough and continue to lock SIM : " + simNo);
					message = TransferMytelTopupSupport.lockSIM(simNo);
					// Save log for balance not enough SIM
					TransferMytelTopupDao.saveTransferMytelTopup(simNo, bal, mobile, amount, "Not enough balance", "Mytel");
					continue forloop;
				}
			}
		}
		return message;
	}
	
	public static void main(String[] args) throws JSONException, IOException, InterruptedException {
		Message msg = doMytelTopupProcess("09689533857", "1000"); //31A
		//System.out.println("Final Result : " + msg.toString());
	}
}
