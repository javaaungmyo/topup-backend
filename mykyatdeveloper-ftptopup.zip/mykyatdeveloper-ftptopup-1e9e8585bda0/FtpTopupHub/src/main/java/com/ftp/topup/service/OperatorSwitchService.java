package com.ftp.topup.service;

import java.util.List;

import com.ftp.topup.model.OperatorSwitch;

public interface OperatorSwitchService {
	List<OperatorSwitch> getAvailableTelco();
	List<OperatorSwitch> getAllOperators();
}
