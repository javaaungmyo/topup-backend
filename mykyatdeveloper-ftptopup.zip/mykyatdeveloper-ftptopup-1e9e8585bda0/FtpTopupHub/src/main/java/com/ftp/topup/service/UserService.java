package com.ftp.topup.service;

import com.ftp.topup.model.User;

public interface UserService {
	User findByUsername(String username);
	User findById(long id);
	User findByMobile(String mobile);
	void updatePassword(String password, long id);
	int updatePassword(String mobile, String password);
	void saveForgotPassword(String mobile, String password);
}
