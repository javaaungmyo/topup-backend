package com.ftp.topup.dao;

import java.util.List;

import com.ftp.topup.model.OperatorSwitch;

public interface OperatorSwitchDao {
	List<OperatorSwitch> getAvailableTelco();
	List<OperatorSwitch> getAllOperators();
}
