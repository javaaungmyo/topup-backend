package com.ftp.topup.dao;

import com.ftp.topup.model.ForgotPasswordInfo;

public interface ForgotPasswordDao {
	void create(ForgotPasswordInfo forgotpasswordinfo);
}
