package com.ftp.topup.controller;

public class Test {
    public static void main(String[] args) {
		int a = 100;
		a = (a * 2)/100;
		
		double amount = Double.parseDouble("2000");
		System.out.println(amount);
	}
}
