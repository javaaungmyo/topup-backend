package com.ftp.topup.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ftp.topup.dao.UserCommissionDao;
import com.ftp.topup.model.UserCommission;

@Service("userCommissionService")
@Transactional
public class UserCommissionServiceImpl implements UserCommissionService {
    
	@Autowired
	UserCommissionDao dao;
	
	public UserCommission findByUserId(long userId) {
		UserCommission commission = dao.findByUserId(userId);
		return commission;
	}

}
