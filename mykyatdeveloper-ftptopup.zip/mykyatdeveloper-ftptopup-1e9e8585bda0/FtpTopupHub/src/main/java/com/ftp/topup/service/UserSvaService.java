package com.ftp.topup.service;

import com.ftp.topup.model.UserSva;

public interface UserSvaService {
	UserSva findByUserId(long userId);
	void updateSva(double balance, long userId);
}
