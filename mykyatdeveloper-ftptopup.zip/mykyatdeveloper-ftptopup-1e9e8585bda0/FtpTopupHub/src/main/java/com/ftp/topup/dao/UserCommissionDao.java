package com.ftp.topup.dao;

import com.ftp.topup.model.UserCommission;

public interface UserCommissionDao {
	UserCommission findByUserId(long userId);
}
