package com.ftp.topup.util;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class ConnectionManager {
	
	public static Connection getConnection() {
	
		Connection connection = null;
		Properties configFile = new Properties();
		try {
			configFile.load(ConnectionManager.class.getClassLoader().getResourceAsStream("application.properties"));
			String driver = configFile.getProperty("jdbc.driver");
			String userName = configFile.getProperty("jdbc.username");
			String password = configFile.getProperty("jdbc.password");
			String url = configFile.getProperty("jdbc.url");;
			
			Class.forName(driver);
			
			connection = DriverManager.getConnection(
					url, userName,
					password);
					
		} catch (IOException e) {
 
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}  catch (SQLException e) {
			
			e.printStackTrace();
		}
		return connection;	
		
	}
	
	public static Connection getProduction_Connection() {
		
		Connection connection = null;
		Properties configFile = new Properties();
		try {
			configFile.load(ConnectionManager.class.getClassLoader().getResourceAsStream("jdbc-mysql-app.properties"));
			String driver = configFile.getProperty("jdbc.driverClassName");
			String userName = configFile.getProperty("jdbc.username");
			String password = configFile.getProperty("jdbc.password");
			String url = configFile.getProperty("jdbc.url");;
			
			Class.forName(driver);
			
			connection = DriverManager.getConnection(
					url, userName,
					password);
					
		} catch (IOException e) {
 
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}  catch (SQLException e) {
			
			e.printStackTrace();
		}
		return connection;	
		
	}

}
