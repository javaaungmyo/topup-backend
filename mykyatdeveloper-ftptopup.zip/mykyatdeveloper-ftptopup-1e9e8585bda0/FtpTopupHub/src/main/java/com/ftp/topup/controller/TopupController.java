package com.ftp.topup.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ftp.topup.eload.ELoadMptTopupService;
import com.ftp.topup.eload.ELoadMytelTopupService;
import com.ftp.topup.eload.ELoadOoredooTopupService;
import com.ftp.topup.eload.ELoadTelenorTopupService;
import com.ftp.topup.model.TelcoProvider;
import com.ftp.topup.model.Message;
import com.ftp.topup.model.OperatorSwitch;
import com.ftp.topup.model.ResponseStatus;
import com.ftp.topup.model.UserCommission;
import com.ftp.topup.model.UserSva;
import com.ftp.topup.transfer.TransferMytelTopupDao;
import com.ftp.topup.transfer.TransferMytelTopupService;
import com.ftp.topup.transfer.TransferOoredooTopupDao;
import com.ftp.topup.transfer.TransferOoredooTopupService;
import com.ftp.topup.util.CommonUtils;
import com.ftp.topup.util.TopupType;

@RestController
public class TopupController extends CommonController {
	private static final Log log = LogFactory.getLog(TopupController.class);

	@PostMapping("/providers")
	public Map<String, Object> getProviders()
			throws JSONException, IOException, InterruptedException {
		ResponseStatus status = null;
		Map<String, Object> results = new HashMap();
		List<OperatorSwitch> eloadSwitchList = operatorSwitchService.getAvailableTelco();
		
		if (eloadSwitchList.size() > 0) {
			status = new ResponseStatus(1, "Available providers");
			results.put("data", eloadSwitchList);
		} else {
			status = new ResponseStatus(0, "Server is temporary unavailable.");
		}
		
		results.put("status", status);
		
		return results;
	}
	
	@PostMapping("/pretopup")
	public Map<String, Object> preTopup(@RequestParam("user_id") long userId, @RequestParam("provider") String provider,
			@RequestParam("mobile") String mobile, @RequestParam("charge") String charge)
			throws JSONException, IOException, InterruptedException {
		ResponseStatus status = null;
		Map<String, Object> results = new HashMap();
		double realAmount = 0;
		UserCommission com = userCommissionService.findByUserId(userId);
		
		status = new ResponseStatus(1, provider);

		if (provider.equalsIgnoreCase(TelcoProvider.MPT.getProviderName())) {
			double chargeAmount = Double.parseDouble(charge);// User charge bill
			double mptCom = (chargeAmount * com.getEloadMpt()) / 100;// User commission
			realAmount = chargeAmount - mptCom;			

		} else if (provider.equalsIgnoreCase(TelcoProvider.Telenor.getProviderName())) {
			double chargeAmount = Double.parseDouble(charge);// User charge bill
			double telenorCom = (chargeAmount * com.getEloadTelenor()) / 100;// User commission
			realAmount = chargeAmount - telenorCom;
			
		} else if (provider.equalsIgnoreCase(TelcoProvider.Ooredoo.getProviderName())) {
			double chargeAmount = Double.parseDouble(charge);// User charge bill
			double ooredooCom = (chargeAmount * com.getEloadOoredoo()) / 100;// User commission
			realAmount = chargeAmount - ooredooCom;			

		} else if (provider.equalsIgnoreCase(TelcoProvider.Mytel.getProviderName())) {
			double chargeAmount = Double.parseDouble(charge);// User charge bill
			double mytelCom = (chargeAmount * com.getEloadMytel()) / 100;// User commission
			realAmount = chargeAmount - mytelCom;			

		} else {
			status = new ResponseStatus(0, "Server is temporary unavailable.");
			log.info("Server is temporary unavailable.");
		}
		
		results.put("data", realAmount);
		results.put("status", status);
		return results;
	}

	@PostMapping("/topup")
	public Map<String, Object> topup(@RequestParam("user_id") long userId, @RequestParam("provider") String provider,
			@RequestParam("mobile") String mobile, @RequestParam("charge") String charge)
			throws JSONException, IOException, InterruptedException {
		ResponseStatus status = null;
		Map<String, Object> results = new HashMap();
		Message message = new Message();

		UserCommission com = userCommissionService.findByUserId(userId);

		if (provider.equalsIgnoreCase(TelcoProvider.MPT.getProviderName())) {

			UserSva sva = svaService.findByUserId(userId);
			double chargeAmount = Double.parseDouble(charge);// User charge bill
			double balance = sva.getBalance(); // User sva
			double mptCom = (chargeAmount * com.getEloadMpt()) / 100;// User commission
			double realAmount = chargeAmount - mptCom;

			if (chargeAmount <= balance) {
				message = ELoadMptTopupService.topup(mobile, charge);
				log.info("MPT eload topup response : " + message.toString());
				if (!message.getResp().contains("pending")) {
					balance = balance - realAmount;
					svaService.updateSva(balance, userId);
					status = new ResponseStatus(1, "Successful!");
					CommonUtils.saveTransaction(mobile, provider, TopupType.ELOAD.getName(), chargeAmount, realAmount, com.getEloadMpt(), balance, userId);
				} else {
					status = new ResponseStatus(0, "Server is busy now! Please wait a while and try again");
				}
			} else {
				status = new ResponseStatus(0, "Your balance is not enough to topup. Please refill your balance.");
			}

		} else if (provider.equalsIgnoreCase(TelcoProvider.Telenor.getProviderName())) {

			UserSva sva = svaService.findByUserId(userId);
			double chargeAmount = Double.parseDouble(charge);// User charge bill
			double balance = sva.getBalance(); // User sva
			double telenorCom = (chargeAmount * com.getEloadTelenor()) / 100;// User commission
			double realAmount = chargeAmount - telenorCom;
			if (chargeAmount <= balance) {
				message = ELoadTelenorTopupService.topup(mobile, charge);
				log.info("Telenor eload topup response : " + message.toString());
				if (!message.getResp().contains("pending")) {
					balance = balance - realAmount;
					svaService.updateSva(balance, userId);
					status = new ResponseStatus(1, "Successful!");
					CommonUtils.saveTransaction(mobile, provider, TopupType.ELOAD.getName(), chargeAmount, realAmount, com.getEloadTelenor(), balance, userId);
				} else {
					status = new ResponseStatus(0, "Server is busy now! Please wait a while and try again");
				} 
			} else {
				status = new ResponseStatus(0, "Your balance is not enough to topup. Please refill your balance.");
			}

		} else if (provider.equalsIgnoreCase(TelcoProvider.Ooredoo.getProviderName())) {

			UserSva sva = svaService.findByUserId(userId);
			double chargeAmount = Double.parseDouble(charge);// User charge bill
			double balance = sva.getBalance(); // User sva
			double ooredooCom = (chargeAmount * com.getEloadOoredoo()) / 100;// User commission
			double realAmount = chargeAmount - ooredooCom;
			if (chargeAmount <= balance) {
				
				String ooredooTopupMethod = TransferOoredooTopupDao.getOoredooTopupMethod();
				if(ooredooTopupMethod.equals("1")){
					message = ELoadOoredooTopupService.topup(mobile, charge);
					log.info("Ooredoo eload topup response : " + message.toString());
					balance = balance - realAmount;
					svaService.updateSva(balance, userId);
					status = new ResponseStatus(1, "Successful!");
					CommonUtils.saveTransaction(mobile, provider, TopupType.ELOAD.getName(), chargeAmount, realAmount, com.getEloadOoredoo(), balance, userId);
				
				}else{
					message = TransferOoredooTopupService.doProcess(mobile, charge);
					balance = balance - realAmount;
					svaService.updateSva(balance, userId);
					status = new ResponseStatus(1, "Successful!");
					CommonUtils.saveTransaction(mobile, provider, TopupType.TRANSFER.getName(), chargeAmount, realAmount, com.getEloadOoredoo(), balance, userId);
				
				}
				
			} else {
				status = new ResponseStatus(0, "Your balance is not enough to topup. Please refill your balance.");
			}

		} else if (provider.equalsIgnoreCase(TelcoProvider.Mytel.getProviderName())) {

			UserSva sva = svaService.findByUserId(userId);
			double chargeAmount = Double.parseDouble(charge);// User charge bill
			double balance = sva.getBalance(); // User sva
			double mytelCom = (chargeAmount * com.getEloadMytel()) / 100;// User commission
			double realAmount = chargeAmount - mytelCom;
			if (chargeAmount <= balance) {
				
				String mytelTopupMethod = TransferMytelTopupDao.getMytelTopupMethod();
				
				if(mytelTopupMethod.equals("1")){
					message = ELoadMytelTopupService.topup(mobile, charge);
					log.info("Mytel eload topup response : " + message.toString());
				}else{
					message = TransferMytelTopupService.doMytelTopupProcess(mobile, charge);
				}
				
				if (!message.getResp().contains("pending")) {
					balance = balance - realAmount;
					svaService.updateSva(balance, userId);
					status = new ResponseStatus(1, "Successful!");
					if(mytelTopupMethod.equals("1")){
						CommonUtils.saveTransaction(mobile, provider, TopupType.ELOAD.getName(), chargeAmount, realAmount, com.getEloadMytel(), balance, userId);
					}else{
						CommonUtils.saveTransaction(mobile, provider, TopupType.TRANSFER.getName(), chargeAmount, realAmount, com.getEloadMytel(), balance, userId);
					}
					
				} else {
					status = new ResponseStatus(0, "Server is busy now! Please wait a while and try again");
				} 
			} else {
				status = new ResponseStatus(0, "Your balance is not enough to topup. Please refill your balance.");
			}

		} else {
			status = new ResponseStatus(0, "Server is temporary unavailable.");
			log.info("Server is temporary unavailable.");
		}

		results.put("status", status);
		return results;
	}
}
