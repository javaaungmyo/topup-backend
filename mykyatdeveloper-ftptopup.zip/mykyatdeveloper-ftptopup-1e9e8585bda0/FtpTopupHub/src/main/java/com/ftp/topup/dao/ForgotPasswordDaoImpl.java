package com.ftp.topup.dao;

import org.springframework.stereotype.Repository;

import com.ftp.topup.model.ForgotPasswordInfo;

@Repository("forgotPasswordDao")
public class ForgotPasswordDaoImpl extends AbstractDao<Integer , ForgotPasswordInfo> implements ForgotPasswordDao{

	@Override
	public void create(ForgotPasswordInfo forgotpasswordinfo) {
		// TODO Auto-generated method stub
		persist(forgotpasswordinfo);
	}

}
