package com.ftp.topup.transfer;

public class TransferOoredooTopupConstants {
	protected static final String USER_NAME = "root";

	protected static final String PASSWORD = "root";

	protected static final String FTP_USSD_GATEWAY = "http://10.20.10.202:80/goip_send_ussd.html?";

	protected static final String FTP_GOIP_GET_STATUS = "http://10.20.10.202:80/goip_get_status.html?";

	protected static final String FTP_GOIP_SEND_CMD = "http://10.20.10.202:80/goip_send_cmd.html?";
}
