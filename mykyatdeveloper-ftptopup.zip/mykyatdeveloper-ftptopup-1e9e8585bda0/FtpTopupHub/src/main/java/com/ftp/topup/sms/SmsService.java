package com.ftp.topup.sms;

import java.io.IOException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;

public class SmsService {
	protected static final String USER_NAME = "root";

	protected static final String PASSWORD = "root";

	protected static final String FTP_USSD_GATEWAY = "http://10.20.10.202/goip_post_sms.html?";
	
	private static final Log log = LogFactory
			.getLog(SmsService.class);

	public static void sendMessage(String toPhoneNo, String smsContent) throws IOException {
		String url = FTP_USSD_GATEWAY + "username=" + USER_NAME + "&password=" + PASSWORD;

		//URL obj = new URL(url);
		//HttpURLConnection con = (HttpURLConnection) obj.openConnection();

		//Gson gson = new Gson();
		HttpClient httpClient = HttpClientBuilder.create().build();
		HttpPost post = new HttpPost(url);

		String tasks = 	"{\"tasks\": [{\"tid\":1, \"to\":\"" + toPhoneNo + "\", \"sms\":\"" +smsContent+ "\"}] }";

		StringEntity postingString = new StringEntity(tasks);// gson.tojson()
																			// converts
		// your pojo to json
		post.setEntity(postingString);
		post.setHeader("Content-type", "application/json");
		HttpResponse response = httpClient.execute(post);

	}
	
	public static void main(String[] args) throws IOException {
		String smsContent = "Your Temporary Password is : ${pickUpCode}";
		smsContent = smsContent.replace("${pickUpCode}", "0101");
		
		//sendMessage("959441331456,959979901101,959450647746", smsContent);
		
		sendMessage("09791608479", smsContent);
		
	}
}
