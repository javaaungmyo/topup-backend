package com.ftp.topup.dao;

import com.ftp.topup.model.User;

public interface UserDao {
	User findByUsername(String username);
	User findByMobile(String mobile);
	User findById(long id);
}
