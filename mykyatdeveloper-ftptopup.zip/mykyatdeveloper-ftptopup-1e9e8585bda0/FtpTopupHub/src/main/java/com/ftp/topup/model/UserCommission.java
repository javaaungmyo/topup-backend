package com.ftp.topup.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "user_commission")
public class UserCommission {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@Column(name = "eload_mpt", nullable = false)
	private double eloadMpt;
	@Column(name = "eload_telenor", nullable = false)
	private double eloadTelenor;
	@Column(name = "eload_ooredoo", nullable = false)
	private double eloadOoredoo;
	@Column(name = "eload_mytel", nullable = false)
	private double eloadMytel;

	@Column(name = "ussd_mpt", nullable = false)
	private double ussdMpt;
	@Column(name = "ussd_telenor", nullable = false)
	private double ussdTelenor;
	@Column(name = "ussd_ooredoo", nullable = false)
	private double ussdOoredoo;
	@Column(name = "ussd_mytel", nullable = false)
	private double ussdMytel;

	@Column(name = "created_date", nullable = false)
	private Date createdDate;
	@Column(name = "updated_date", nullable = false)
	private Date updatedDate;
	@OneToOne
	@JoinColumn(name = "user_id")
	private User user;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public double getEloadMpt() {
		return eloadMpt;
	}

	public void setEloadMpt(double eloadMpt) {
		this.eloadMpt = eloadMpt;
	}

	public double getEloadTelenor() {
		return eloadTelenor;
	}

	public void setEloadTelenor(double eloadTelenor) {
		this.eloadTelenor = eloadTelenor;
	}

	public double getEloadOoredoo() {
		return eloadOoredoo;
	}

	public void setEloadOoredoo(double eloadOoredoo) {
		this.eloadOoredoo = eloadOoredoo;
	}

	public double getEloadMytel() {
		return eloadMytel;
	}

	public void setEloadMytel(double eloadMytel) {
		this.eloadMytel = eloadMytel;
	}

	public double getUssdMpt() {
		return ussdMpt;
	}

	public void setUssdMpt(double ussdMpt) {
		this.ussdMpt = ussdMpt;
	}

	public double getUssdTelenor() {
		return ussdTelenor;
	}

	public void setUssdTelenor(double ussdTelenor) {
		this.ussdTelenor = ussdTelenor;
	}

	public double getUssdOoredoo() {
		return ussdOoredoo;
	}

	public void setUssdOoredoo(double ussdOoredoo) {
		this.ussdOoredoo = ussdOoredoo;
	}

	public double getUssdMytel() {
		return ussdMytel;
	}

	public void setUssdMytel(double ussdMytel) {
		this.ussdMytel = ussdMytel;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}
