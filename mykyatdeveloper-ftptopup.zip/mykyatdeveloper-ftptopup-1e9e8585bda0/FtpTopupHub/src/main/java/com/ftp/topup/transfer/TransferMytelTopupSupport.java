package com.ftp.topup.transfer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ftp.topup.model.Message;
import com.ftp.topup.model.Status;

public class TransferMytelTopupSupport extends TransferMytelTopupConstants {

	public static Message topup(String mobile, String charge, String port) throws InterruptedException, JSONException, IOException {

		Message msg = topupRequest(port);
		System.out.println("Topupup request res : " + msg);
		msg = inputCharge(charge, port);
		System.out.println("Input Charge res : " + msg);
		msg = inputMobile(mobile, port);
		System.out.println("input mobile res : " + msg);
		msg = topupConfirm(port);
		System.out.println("Topup confirm res : " + msg);

		if (msg.getResp().contains("Confirm")) {
			msg = topupConfirm(port);
			System.out.println("Topup twice confirm : " + msg);
		}
		return msg;
	}

	public static void removePorts(List<String> availablePorts, String ports) {
		List<String> portList = changePortList(ports);
		for (String p : portList) {
			if (availablePorts.contains(p)) {
				int index = availablePorts.indexOf(p);
				availablePorts.remove(index);
			}
		}
	}

	public static List<String> getAvaliablePorts() throws InterruptedException, JSONException, IOException {
		String url = FTP_USSD_GATEWAY + "username=" + USER_NAME + "&password=" + PASSWORD;

		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		ObjectMapper objectMapper = new ObjectMapper();
		Message msgTopupRequest = objectMapper.readValue(response.toString(), Message.class);
		String ports = msgTopupRequest.getPort();
		List<String> portList = changePortList(ports);
		return portList;
	}

	private static List<String> changePortList(String portString) {
		List<String> portList = new ArrayList();
		StringTokenizer st = new StringTokenizer(portString, ",");
		while (st.hasMoreTokens()) {
			String s = st.nextToken();
			if (s.contains("-")) {
				int _points = s.indexOf("-");
				int endPoint = s.length();
				int start = Integer.parseInt(s.substring(0, _points));
				int end = Integer.parseInt(s.substring((_points + 1), endPoint));
				for (int i = start; i <= end; i++) {
					portList.add(String.valueOf(i));
				}
			} else {
				portList.add(s);
			}
		}

		return portList;
	}

	public static Status getCurrentEnableSIMStatus(String port) throws IOException, JSONException {
		String url = FTP_GOIP_GET_STATUS + "username=root&password=root&port=" + port;

		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		JSONObject jsonObj = new JSONObject(response.toString());
		JSONArray array = jsonObj.getJSONArray("status");
		ObjectMapper objectMapper = new ObjectMapper();

		List<Status> statusList = objectMapper.readValue(array.toString(),
				objectMapper.getTypeFactory().constructCollectionType(List.class, Status.class));
		Status status = statusList.get(0);
		return status;
	}

	public static Message lockSIM(String simNo) throws JsonParseException, JsonMappingException, IOException {

		String url = FTP_GOIP_SEND_CMD + "username=" + USER_NAME + "&password=" + PASSWORD + "&port=" + simNo
				+ "&op=lock";

		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		ObjectMapper objectMapper = new ObjectMapper();
		Message msg = objectMapper.readValue(response.toString(), Message.class);
		return msg;
	}

	static Message changeEnglish(String port) throws JsonParseException, JsonMappingException, IOException {

		String url = FTP_USSD_GATEWAY + "username=" + USER_NAME + "&password=" + PASSWORD + "&port=" + port
				+ "&ussd=*106*7*1%23";

		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		ObjectMapper objectMapper = new ObjectMapper();
		Message msg = objectMapper.readValue(response.toString(), Message.class);
		return msg;
	}

	/*public static Message checkBalance(String port) throws JsonParseException, JsonMappingException, IOException, InterruptedException, JSONException {

		String url = FTP_USSD_GATEWAY + "username=" + USER_NAME + "&password=" + PASSWORD + "&port=" + port + "&ussd=*124%23";

		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		ObjectMapper objectMapper = new ObjectMapper();
		Message balanceMessage = objectMapper.readValue(response.toString(), Message.class);
		return balanceMessage;
	}*/
	
	
	public static Message checkBalance(String port) throws JsonParseException, JsonMappingException, IOException, InterruptedException, JSONException {

		String url = FTP_USSD_GATEWAY + "username=" + USER_NAME + "&password=" + PASSWORD + "&port=" + port
				+ "&ussd=*9666%23";

		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		ObjectMapper objectMapper = new ObjectMapper();
		Message balanceMessage = objectMapper.readValue(response.toString(), Message.class);		
		balanceMessage = topupConfirm(port);
		return balanceMessage;
	} 

	public static Message topupRequest(String port) throws InterruptedException, JSONException, IOException {

		//String url = FTP_USSD_GATEWAY + "username=" + USER_NAME + "&password=" + PASSWORD + "&port=" + port + "&ussd=*544%23";
		
		String url = FTP_USSD_GATEWAY + "username=" + USER_NAME + "&password=" + PASSWORD + "&port=" + port + "&ussd=*96693%23";

		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		ObjectMapper objectMapper = new ObjectMapper();
		Message msg = objectMapper.readValue(response.toString(), Message.class);
		return msg;
	}

	public static Message inputCharge(String charge, String port) throws InterruptedException, JSONException, IOException {

		String url = FTP_USSD_GATEWAY + "username=" + USER_NAME + "&password=" + PASSWORD + "&port=" + port + "&ussd="
				+ charge;

		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		ObjectMapper objectMapper = new ObjectMapper();
		Message msg = objectMapper.readValue(response.toString(), Message.class);
		return msg;
	}

	public static Message inputMobile(String mobile, String port) throws InterruptedException, JSONException, IOException {

		String url = FTP_USSD_GATEWAY + "username=" + USER_NAME + "&password=" + PASSWORD + "&port=" + port + "&ussd="
				+ mobile;

		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		ObjectMapper objectMapper = new ObjectMapper();
		Message msg = objectMapper.readValue(response.toString(), Message.class);
		return msg;
	}

	public static Message topupConfirm(String port) throws InterruptedException, JSONException, IOException {
		String url = FTP_USSD_GATEWAY + "username=" + USER_NAME + "&password=" + PASSWORD + "&port=" + port + "&ussd=1";

		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		ObjectMapper objectMapper = new ObjectMapper();
		Message msg = objectMapper.readValue(response.toString(), Message.class);
		return msg;
	}

}
