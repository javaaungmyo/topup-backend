package com.ftp.topup.eload;

public class Port {
	private int id;
	private String port;
	private int status;
	private int flag;

	public Port() {
	}

	public Port(int id, String port, int status, int flag) {
		super();
		this.id = id;
		this.port = port;
		this.status = status;
		this.flag = flag;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getFlag() {
		return flag;
	}

	public void setFlag(int flag) {
		this.flag = flag;
	}

	@Override
	public String toString() {
		return "Port [id=" + id + ", port=" + port + ", status=" + status + ", flag=" + flag + "]";
	}

}
