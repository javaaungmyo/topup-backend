package com.ftp.topup.eload;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ftp.topup.util.ConnectionManager;

public class ELoadMptTopupDao {
	// Set table name
	private static final String TABLE_NAME = "eload_mpt_sim";	
	private static final Log log = LogFactory.getLog(ELoadMptTopupDao.class);

	public static Port getAvailablePort() {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		Port port = new Port();
		try {
			connection = ConnectionManager.getConnection();
			String sql = "SELECT * FROM " + TABLE_NAME + " where flag = 1 and status = 1;";
			preparedStatement = connection.prepareStatement(sql);
			ResultSet rs = preparedStatement.executeQuery();

			if (rs != null) {

				while (rs.next()) {
					port.setId(rs.getInt(1));
					port.setPort(rs.getString(2));
					port.setStatus(rs.getInt(3));
					port.setFlag(rs.getInt(4));
				}
			}
			connection.close();

		} catch (Exception e) {

			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e1) {

				}
			}
		}

		return port;
	}

	public static Port getNextPortById(int id) {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		Port port = new Port();
		try {
			connection = ConnectionManager.getConnection();
			String sql = "SELECT * FROM " + TABLE_NAME + " where status = 0 and flag = 1 and id = ?";
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, id);
			ResultSet rs = preparedStatement.executeQuery();

			if (rs != null) {

				while (rs.next()) {
					port.setId(rs.getInt(1));
					port.setPort(rs.getString(2));
					port.setStatus(rs.getInt(3));
					port.setFlag(rs.getInt(4));
				}
			}
			connection.close();

		} catch (Exception e) {

			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e1) {

				}
			}
		}

		return port;
	}

	public static int updateStatusById(int id, int status) {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int updatedStatus = 0;
		try {
			connection = ConnectionManager.getConnection();
			String sql = "update " + TABLE_NAME + " set status = ? where id = ?";
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, status);
			preparedStatement.setInt(2, id);
			updatedStatus = preparedStatement.executeUpdate();
			connection.close();

		} catch (Exception e) {

			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e1) {

				}
			}
		}

		return updatedStatus;
	}
	
	public static int getMinId() {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int minId = 0;
		try {
			connection = ConnectionManager.getConnection();
			String sql = "SELECT min(id) FROM " + TABLE_NAME + " where status = 0 and flag = 1";
			preparedStatement = connection.prepareStatement(sql);
			ResultSet rs = preparedStatement.executeQuery();
			
			if (rs != null) {

				while (rs.next()) {
					minId = rs.getInt(1);
				}
			}
			connection.close();

		} catch (Exception e) {

			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e1) {

				}
			}
		}

		return minId;
	}
	
	public static int getMaxId() {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int minId = 0;
		try {
			connection = ConnectionManager.getConnection();
			String sql = "SELECT max(id) FROM " + TABLE_NAME + " where status = 0 and flag = 1";
			preparedStatement = connection.prepareStatement(sql);
			ResultSet rs = preparedStatement.executeQuery();
			
			if (rs != null) {

				while (rs.next()) {
					minId = rs.getInt(1);
				}
			}
			connection.close();

		} catch (Exception e) {

			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e1) {

				}
			}
		}

		return minId;
	}
	
	public static String getPort() {
		int minId = getMinId();
		int maxId = getMaxId();
		Port availablePort = getAvailablePort();
		int availableId = availablePort.getId();
		String currentPort = availablePort.getPort();
		//
		boolean nextIdFound = false;
		int nextId = 0;		
		
		//log.info("available id : " + availableId + ", Min id : " + minId + ", Max id : " + maxId);
		
		if (minId != maxId) {
			
			for (int i = availableId; i <= maxId; i++) {
				Port port = getNextPortById(i);
				
				if (port.getId() != 0) {
					nextIdFound = true;
					nextId = port.getId();
					break;
				}
			}
			
			if (nextIdFound == false) {
				nextId = minId;
			}
		} else {		
			
			if (minId == 0) {
				minId = availableId;
			}
			nextId = minId;
		}
		
		updateStatusById(availableId, 0);
		updateStatusById(nextId, 1);
		
		//log.info("current port : " + currentPort + ", next id : " + nextId);
		
		return currentPort;
	}
	
	public static String getMptTopupMethod() {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			connection = ConnectionManager.getConnection();
			String authKeySelectString;
			authKeySelectString = "SELECT value FROM eload_transfer_switch WHERE name = ?";
			preparedStatement = connection.prepareStatement(authKeySelectString);
			preparedStatement.setString(1, "mpt");
			ResultSet result = preparedStatement.executeQuery();

			if (result != null) {
				while (result.next()) {
					return result.getString(1);
				}
			}
			connection.close();
		} catch (Exception e) {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e1) {
				}
			}
		}

		return null;
	}

	public static void main(String[] args) {
		getPort();
	}
}