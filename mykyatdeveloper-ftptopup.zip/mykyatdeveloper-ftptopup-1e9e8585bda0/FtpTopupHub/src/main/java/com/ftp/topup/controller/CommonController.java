package com.ftp.topup.controller;

import org.springframework.beans.factory.annotation.Autowired;

import com.ftp.topup.service.OperatorSwitchService;
import com.ftp.topup.service.UserCommissionService;
import com.ftp.topup.service.UserService;
import com.ftp.topup.service.UserSvaService;

public class CommonController {
	@Autowired
	UserService service;
	@Autowired
	UserSvaService svaService;
	@Autowired
	UserCommissionService userCommissionService;
	@Autowired
	OperatorSwitchService operatorSwitchService;
}
