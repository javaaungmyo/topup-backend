package com.ftp.topup.util;

public enum TopupType {
    ELOAD("eload"), TRANSFER("transfer");
	
	private String name;
    
	TopupType(String name) {
	    this.name = name;
	}
	
	public String getName() {
		return name;
	}	
}
