package com.ftp.topup.dao;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.ftp.topup.model.UserSva;

@Repository("userSvaDao")
public class UserSvaDaoImpl extends AbstractDao<Long, UserSva> implements UserSvaDao {

	public UserSva findByUserId(long userId) {
		Criteria crit = createEntityCriteria();
		crit.add(Restrictions.eq("user.id", userId));
		UserSva userSva = (UserSva) crit.uniqueResult();
		return userSva;
	}

}
