package com.ftp.topup.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ftp.topup.dao.UserSvaDao;
import com.ftp.topup.model.UserSva;

@Service("userSvaService")
@Transactional
public class UserSvaServiceImpl implements UserSvaService {
    
	@Autowired
	UserSvaDao dao;
	
	public UserSva findByUserId(long userId) {
		UserSva sva = dao.findByUserId(userId);
		return sva;
	}
	
	public void updateSva(double balance, long userId) {
		UserSva sva = dao.findByUserId(userId);
		
		if (sva != null) {
			sva.setBalance(balance);
		}
	}
    
}
