package com.ftp.topup.model;

public enum TelcoProvider {
	
	MPT("mpt"), Telenor("telenor"), Ooredoo("ooredoo"), Mytel("mytel");
	
	private String name;
    
	TelcoProvider(String name) {
	    this.name = name;
	}
	
	public String getProviderName() {
		return name;
	}	
}
