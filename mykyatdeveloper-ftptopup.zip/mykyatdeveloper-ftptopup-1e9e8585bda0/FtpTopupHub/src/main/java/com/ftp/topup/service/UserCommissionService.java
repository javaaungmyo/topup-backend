package com.ftp.topup.service;

import com.ftp.topup.model.UserCommission;

public interface UserCommissionService {
	UserCommission findByUserId(long userId);
}
