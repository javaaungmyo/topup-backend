package com.ftp.topup.dao;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.ftp.topup.model.User;

@Repository("userDao")
public class UserDaoImpl extends AbstractDao<Long, User> implements UserDao {
	public User findByUsername(String username) {
		Criteria crit = createEntityCriteria();
		crit.add(Restrictions.eq("username", username));
		User user = (User) crit.uniqueResult();
		return user;
	}
	
	public User findByMobile(String mobile) {
		Criteria crit = createEntityCriteria();
		crit.add(Restrictions.like("mobile", "%" + mobile + "%"));
		User user = (User) crit.uniqueResult();
		return user;
	}

	public User findById(long id) {
		Criteria crit = createEntityCriteria();
		crit.add(Restrictions.eq("id", id));
		User user = (User) crit.uniqueResult();
		return user;
	}
}
