package com.ftp.topup.eload;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ftp.topup.model.Message;

public class ELoadMptTopupService extends ELoadMptTopupConstants {
	
	private static final Log log = LogFactory.getLog(ELoadMptTopupService.class);

	public static Message topup(String mobile, String amount) throws IOException, InterruptedException, JSONException {
		Message message = new Message();
		String port = ELoadMptTopupDao.getPort();
		
		// Step 1, prerequest
		message = preRequestTopup(port, amount, mobile);
		// Step 2, confirm
		message = confirm(mobile, port);
		// Step 3, confirm (optional)
		if (message.getResp().contains("confirm")) {
			message = confirm(mobile, port);
			log.info(mobile + " -> twice confirmation.");
		}
		return message;
	}

	public static Message preRequestTopup(String port, String amount, String mobile) throws InterruptedException, JSONException, IOException {
		String url = FTP_USSD_GATEWAY + "username=" + USER_NAME + "&password=" + PASSWORD + "&port=" + port + "&ussd=*125*" + amount + "*" + mobile + "*5678" + "%23";

		log.info(mobile + " -> mpt eload topup prerequest : " + url);

		Message msg = new Message();
		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();
		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		ObjectMapper objectMapper = new ObjectMapper();
		msg = objectMapper.readValue(response.toString(), Message.class);
		log.info(mobile + " -> mpt eload topup prerequest response : " + msg.toString());
		return msg;
	}

	public static Message confirm(String mobile, String port) throws InterruptedException, JSONException, IOException {
		String url = FTP_USSD_GATEWAY + "username=" + USER_NAME + "&password=" + PASSWORD + "&port=" + port + "&ussd=1";

		log.info(mobile + " -> mpt eload topup confirm request : " + url);

		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		ObjectMapper objectMapper = new ObjectMapper();
		Message msg = objectMapper.readValue(response.toString(), Message.class);

		log.info(mobile + " -> mpt eload topup confirm response : " + msg.toString());
		return msg;
	}
}
