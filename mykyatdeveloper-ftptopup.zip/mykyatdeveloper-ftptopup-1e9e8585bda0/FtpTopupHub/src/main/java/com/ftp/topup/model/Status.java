package com.ftp.topup.model;

public class Status {
	private String port;
	private String seq;
	private String st;
	private String bal;
	private String opr;
	private String sn;
	private String imei;
	private String imsi;
	private String iccid;
	private String sim;
	private String sig;

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public String getSeq() {
		return seq;
	}

	public void setSeq(String seq) {
		this.seq = seq;
	}

	public String getSt() {
		return st;
	}

	public void setSt(String st) {
		this.st = st;
	}

	public String getBal() {
		return bal;
	}

	public void setBal(String bal) {
		this.bal = bal;
	}

	public String getOpr() {
		return opr;
	}

	public void setOpr(String opr) {
		this.opr = opr;
	}

	public String getSn() {
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	public String getImei() {
		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	public String getImsi() {
		return imsi;
	}

	public void setImsi(String imsi) {
		this.imsi = imsi;
	}

	public String getIccid() {
		return iccid;
	}

	public void setIccid(String iccid) {
		this.iccid = iccid;
	}

	public String getSim() {
		return sim;
	}

	public void setSim(String sim) {
		this.sim = sim;
	}

	public String getSig() {
		return sig;
	}

	public void setSig(String sig) {
		this.sig = sig;
	}

	@Override
	public String toString() {
		return "Status [port=" + port + ", seq=" + seq + ", st=" + st + ", bal=" + bal + ", opr=" + opr + ", sn=" + sn
				+ ", imei=" + imei + ", imsi=" + imsi + ", iccid=" + iccid + ", sim=" + sim + ", sig=" + sig + "]";
	}

}
