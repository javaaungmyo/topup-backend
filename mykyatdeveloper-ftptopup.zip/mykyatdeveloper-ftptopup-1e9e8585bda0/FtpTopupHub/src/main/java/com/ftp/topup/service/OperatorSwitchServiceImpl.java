package com.ftp.topup.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ftp.topup.dao.OperatorSwitchDao;
import com.ftp.topup.model.OperatorSwitch;

@Service("operatorSwitchService")
@Transactional
public class OperatorSwitchServiceImpl implements OperatorSwitchService {
	
	@Autowired
	OperatorSwitchDao dao;

	public List<OperatorSwitch> getAvailableTelco() {
		List<OperatorSwitch> operatorSwitchList = dao.getAvailableTelco();
		return operatorSwitchList;
	}

	@Override
	public List<OperatorSwitch> getAllOperators() {
		// TODO Auto-generated method stub
		
		return dao.getAllOperators();
	}
}
