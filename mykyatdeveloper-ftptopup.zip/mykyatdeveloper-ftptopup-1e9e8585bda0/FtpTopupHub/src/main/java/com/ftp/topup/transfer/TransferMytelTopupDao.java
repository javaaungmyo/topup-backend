package com.ftp.topup.transfer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import com.ftp.topup.util.ConnectionManager;

public class TransferMytelTopupDao {
	
	public static boolean saveTransferMytelTopup(String simNo, int balance, String requestedNumber, String requestedBill,
			String description, String operator) {

		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			connection = ConnectionManager.getProduction_Connection();
			String saveFtpEjoinSimStatusQuery = "INSERT INTO transfer_mytel_locked_sim(sim_no, balance, requested_number, requested_bill, description, operator, created_date) "
					+ "VALUES(?,?,?,?,?,?,?)";

			preparedStatement = connection.prepareStatement(saveFtpEjoinSimStatusQuery);
			preparedStatement.setString(1, simNo);
			preparedStatement.setInt(2, balance);
			preparedStatement.setString(3, requestedNumber);
			preparedStatement.setString(4, requestedBill);
			preparedStatement.setString(5, description);
			preparedStatement.setString(6, operator);
			preparedStatement.setTimestamp(7, getCurrentDate());

			int i = preparedStatement.executeUpdate();

			if (i > 0) {
				return Boolean.TRUE;
			} else {
				return Boolean.FALSE;
			}

		} catch (Exception e) {

			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e1) {

				}
			}
			return Boolean.FALSE;
		}
	}

	private static Timestamp getCurrentDate() {
		java.util.Date today = new java.util.Date();
		return new Timestamp(today.getTime());
	}

	public static String getMytelTopupMethod() {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			connection = ConnectionManager.getProduction_Connection();
			String authKeySelectString;
			authKeySelectString = "SELECT value FROM eload_transfer_switch WHERE name = ?";
			preparedStatement = connection.prepareStatement(authKeySelectString);
			preparedStatement.setString(1, "mytel");
			ResultSet result = preparedStatement.executeQuery();

			if (result != null) {
				while (result.next()) {
					return result.getString(1);
				}
			}
			connection.close();
		} catch (Exception e) {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e1) {
				}
			}
		}

		return null;
	}

	
}
