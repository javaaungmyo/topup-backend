package com.ftp.topup.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ftp.topup.model.OperatorSwitch;
import com.ftp.topup.model.ResponseStatus;
import com.ftp.topup.model.Transaction;
import com.ftp.topup.model.TransactionRequestBean;
import com.ftp.topup.service.OperatorSwitchService;
import com.ftp.topup.util.CommonUtils;

@RestController
public class TransactionController {
	
	@Autowired
	OperatorSwitchService operatorSwitchServices;
	
	@PostMapping("/txns")
	public Map<String, Object> eload(@RequestBody TransactionRequestBean req)
			throws JSONException, IOException, InterruptedException {
		ResponseStatus status = null;
		Map<String, Object> results = new HashMap();
		List<Transaction> txns = CommonUtils.getTransactionList(req);
		status = new ResponseStatus(1, "Transactions details");
		results.put("status", status);
		results.put("data", txns);
		return results;
	}
	
	@PostMapping("/getAllOperators")
	public Map<String, Object> getAllOperators()
			throws JSONException, IOException, InterruptedException {
		ResponseStatus status = null;
		Map<String, Object> results = new HashMap();
		List<OperatorSwitch> txns = new ArrayList<OperatorSwitch>();
		List<OperatorSwitch> op_list = new ArrayList<OperatorSwitch>();
		
		
		txns = operatorSwitchServices.getAllOperators();
		if(txns.size()>0){
			OperatorSwitch op = new OperatorSwitch();
			op.setId(0);
			op.setOperator("All");
			op.setStatus(1);
			op_list.add(op);
			op_list.addAll(txns);
		}
		
		status = new ResponseStatus(1, "Operator Lists");
		results.put("status", status);
		results.put("data", op_list);
		return results;
	}
}
