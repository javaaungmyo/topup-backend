package com.ftp.topup.transfer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;

import com.ftp.topup.util.ConnectionManager;

public class TransferMptTopupDao {
	private static Timestamp getCurrentDate() {
		java.util.Date today = new java.util.Date();
		return new Timestamp(today.getTime());
	}

	/*private static Timestamp getCurrentDate(Date date) {
		return new Timestamp(date.getTime());
	}*/

	public static boolean saveFtpEjoinSimStatus(String simNo, int balance, String requestedNumber, String requestedBill,
			String description, String operator) {

		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {

			connection = ConnectionManager.getConnection();

			String saveFtpEjoinSimStatusQuery = "INSERT INTO transfer_mpt_locked_sim(sim_no, balance, requested_number, requested_bill, description, operator, created_date) "
					+ "VALUES(?,?,?,?,?,?,?)";

			preparedStatement = connection.prepareStatement(saveFtpEjoinSimStatusQuery);
			preparedStatement.setString(1, simNo);
			preparedStatement.setInt(2, balance);
			preparedStatement.setString(3, requestedNumber);
			preparedStatement.setString(4, requestedBill);
			preparedStatement.setString(5, description);
			preparedStatement.setString(6, operator);
			preparedStatement.setTimestamp(7, getCurrentDate());

			int i = preparedStatement.executeUpdate();

			if (i > 0) {

				return Boolean.TRUE;
			} else {

				return Boolean.FALSE;
			}

		} catch (Exception e) {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e1) {

				}
			}
			return Boolean.FALSE;
		}
	}
}
