package com.ftp.topup.eload;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ftp.topup.model.Message;

public class ELoadMytelTopupService extends ELoadMytelTopupConstants {

	private static final Log log = LogFactory.getLog(ELoadMytelTopupService.class);

	public static Message topup(String mobile, String charge) throws IOException, InterruptedException, JSONException {

		Message message = new Message();		
		String port = ELoadMytelTopupDao.getPort();
		
        // Step 1, prerequest
		message = preRequestTopup(port, mobile);
		// Step 2, choice sell
		message = choiceSell(port, mobile);
		// Step 3, choice eload
		message = choiceELoad(port, mobile);
		// Step 4, input phone no
		message = inputPhoneNo(port, mobile);
		// Step 5, select amount no
		message = selectAmountNo(port, mobile, getAmountSelectionNo(charge));
		// Step 6, input password
		message = inputPassword(port, mobile);
		// Step 7, confirm
		message = Confirm(port, mobile);

		return message;
	}

	public static Message preRequestTopup(String port, String mobile) throws InterruptedException, JSONException, IOException {
		String url = FTP_USSD_GATEWAY + "username=" + USER_NAME + "&password=" + PASSWORD + "&port=" + port + "&ussd=*888%23";

		log.info(mobile + " -> mytel eload topup prerequest : " + url);

		Message msg = new Message();
		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		ObjectMapper objectMapper = new ObjectMapper();
		msg = objectMapper.readValue(response.toString(), Message.class);
		
		log.info(mobile + " -> mytel eload topup prerequest response : " + msg.toString());
		
		return msg;
	}
	
	public static Message choiceSell(String port, String mobile) throws InterruptedException, JSONException, IOException {
		String url = FTP_USSD_GATEWAY + "username=" + USER_NAME + "&password=" + PASSWORD + "&port=" + port + "&ussd=1";
		
		log.info(mobile + " -> mytel eload choice sell request : " + url);
		
		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		ObjectMapper objectMapper = new ObjectMapper();
		Message msg = objectMapper.readValue(response.toString(), Message.class);

		log.info(mobile + " -> mytel eload choice sell response : " + msg.toString());
		
		return msg;
	}
	
	public static Message choiceELoad(String port, String mobile) throws InterruptedException, JSONException, IOException {
		String url = FTP_USSD_GATEWAY + "username=" + USER_NAME + "&password=" + PASSWORD + "&port=" + port + "&ussd=1";
		
		log.info(mobile + " -> mytel eload choice request : " + url);
		
		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		ObjectMapper objectMapper = new ObjectMapper();
		Message msg = objectMapper.readValue(response.toString(), Message.class);

		log.info(mobile + " -> mytel eload choice response : " + msg.toString());
		
		return msg;
	}
	
	public static Message inputPhoneNo(String port, String mobile) throws InterruptedException, JSONException, IOException {
		String url = FTP_USSD_GATEWAY + "username=" + USER_NAME + "&password=" + PASSWORD + "&port=" + port + "&ussd=" + mobile;
		
		log.info(mobile + " -> mytel eload input phone no request : " + url);
		
		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		ObjectMapper objectMapper = new ObjectMapper();
		Message msg = objectMapper.readValue(response.toString(), Message.class);

		log.info(mobile + " -> mytel eload input phone no response : " + msg.toString());
		
		return msg;
	}
	
	public static Message selectAmountNo(String port, String mobile, String amountSelectionNo) throws InterruptedException, JSONException, IOException {
		String url = FTP_USSD_GATEWAY + "username=" + USER_NAME + "&password=" + PASSWORD + "&port=" + port + "&ussd=" + amountSelectionNo;
		
		log.info(mobile + " -> mytel eload select amount no request : " + url);
		
		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		ObjectMapper objectMapper = new ObjectMapper();
		Message msg = objectMapper.readValue(response.toString(), Message.class);

		log.info(mobile + " -> mytel eload select amount no response : " + msg.toString());
		
		return msg;
	}
	
	public static Message inputPassword(String port, String mobile) throws InterruptedException, JSONException, IOException {
		String url = FTP_USSD_GATEWAY + "username=" + USER_NAME + "&password=" + PASSWORD + "&port=" + port + "&ussd=990099";
		
		log.info(mobile + " -> mytel eload input password request : " + url);
		
		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		ObjectMapper objectMapper = new ObjectMapper();
		Message msg = objectMapper.readValue(response.toString(), Message.class);

		log.info(mobile + " -> mytel eload input password response : " + msg.toString());
		
		return msg;
	}
	
	public static Message Confirm(String port, String mobile) throws InterruptedException, JSONException, IOException {
		String url = FTP_USSD_GATEWAY + "username=" + USER_NAME + "&password=" + PASSWORD + "&port=" + port + "&ussd=1";
		
		log.info(mobile + " -> mytel eload confirm request : " + url);
		
		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		ObjectMapper objectMapper = new ObjectMapper();
		Message msg = objectMapper.readValue(response.toString(), Message.class);

		log.info(mobile + " -> mytel eload confirm response : " + msg.toString());
		
		return msg;
	}
	
	public static String getAmountSelectionNo(String amount) {
		String no = "0";
		if (amount.equals("1000")) {
			no = "1";
		} 
		if (amount.equals("2000")) {
			no = "2";
		}
		if (amount.equals("3000")) {
			no = "3";
		}
		if (amount.equals("5000")) {
			no = "4";
		}
		if (amount.equals("10000")) {
			no = "5";
		}
		
		return no;
	}
	
	public static void main(String[] args) {
		System.out.println(getAmountSelectionNo("1000"));
	}

}
