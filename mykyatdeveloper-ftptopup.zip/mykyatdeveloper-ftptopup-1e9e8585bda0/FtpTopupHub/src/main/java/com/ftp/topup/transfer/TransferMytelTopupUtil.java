package com.ftp.topup.transfer;

public class TransferMytelTopupUtil {
	public static String getAmount(String resp) {
    	resp = resp.substring(34, 43);
    	resp = resp.replace("K", "");
    	resp = resp.replace("s", "");
    	resp = resp.replace(",", "");
    	resp = resp.replace("v", "");
    	resp = resp.replace("a", "");
    	resp = resp.replace("l", "");
    	resp = resp.replace("i", "");
    	resp = resp.replace("d", "");
    	System.out.println(resp);
    	return resp;
    }
    
    public static void main(String[] args) {
	    //getAmount("09670300576. Your main balance is 55901 Ks, valid until 23/7/2020.");	
    	getAmount("09670385774. Your main balance is 92650Ks,valid until 13/05/2020. Price plan: MiteTal. 920MB+920SMS=968Ks! Dial *966*32#");
	}
}
