package com.ftp.topup.transfer;

public class TransferOoredooTopupUtil {
    public static String getAmount(String resp) {
    	resp = resp.substring(4, 14);
    	resp = resp.replace("K", "");
    	resp = resp.replace("s", "");
    	resp = resp.replace(",", "");
    	resp = resp.replace("V", "");
    	resp = resp.replace("a", "");
    	resp = resp.replace("l", "");
    	resp = resp.replace("i", "");
    	resp = resp.replace("d", "");
    	resp = resp.replace(":", "");
    	resp = resp.replace(".", "");
    	System.out.println(resp);
    	return resp;
    }
    
    public static void main(String[] args) {
	    getAmount("Bal: 23456789Ks, Valid: 01/04/2020");	
	}
}
