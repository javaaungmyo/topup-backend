package com.ftp.topup.dao;

import com.ftp.topup.model.UserSva;

public interface UserSvaDao {
	 UserSva findByUserId(long userId);
}
