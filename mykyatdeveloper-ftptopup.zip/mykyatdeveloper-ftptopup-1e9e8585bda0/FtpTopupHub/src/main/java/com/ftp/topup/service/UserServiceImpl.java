package com.ftp.topup.service;


import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ftp.topup.dao.ForgotPasswordDao;
import com.ftp.topup.dao.UserDao;
import com.ftp.topup.model.ForgotPasswordInfo;
import com.ftp.topup.model.User;

@Service("userService")
@Transactional
public class UserServiceImpl implements UserService {
    
	@Autowired
	UserDao dao;
	
	@Autowired
	ForgotPasswordDao forgotPasswordDao;
	
	public User findByUsername(String username) {
		User user = dao.findByUsername(username);
		return user;
	}

	public User findById(long id) {
		User user = dao.findById(id);
		return user;
	}
	
	public void updatePassword(String password, long id) {
		User user = dao.findById(id);
		if (user != null) {
			user.setPassword(password);
		}
	}
	
	public int updatePassword(String mobile, String password) {
		int status = 0;
		User user = dao.findByMobile(mobile);
		if (user != null) {
			status = 1;
			user.setPassword(password);
		}
		return status;
	}

	@Override
	public User findByMobile(String mobile) {
		User user = dao.findByMobile(mobile);
		return user;
	}

	@Override
	public void saveForgotPassword(String mobile, String password) {
		// TODO Auto-generated method stub
		User user = dao.findByMobile(mobile);
		ForgotPasswordInfo info = new ForgotPasswordInfo();
		if(user != null){
			info.setUserid(user.getUsername());
			info.setForgotPassword(1);
			info.setMobile(mobile);
			info.setCreatedBy(user.getId());
			info.setCreatedDate(new Date());
			
			forgotPasswordDao.create(info);
		}
	}

}
