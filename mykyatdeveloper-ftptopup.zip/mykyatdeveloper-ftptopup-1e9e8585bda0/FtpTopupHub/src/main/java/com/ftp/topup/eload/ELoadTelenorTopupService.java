package com.ftp.topup.eload;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONException;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ftp.topup.model.Message;

public class ELoadTelenorTopupService extends ELoadTelenorTopupConstants {

	private static final Log log = LogFactory.getLog(ELoadTelenorTopupService.class);

	public static Message topup(String mobile, String amount) throws IOException, InterruptedException, JSONException {
		Message message = new Message();		
		String port = ELoadTelenorTopupDao.getPort();
		
		// Step 1, prerequest
		message = preRequestTopup(port, mobile, "9");
		
		if (! StringUtils.isEmpty(message.getResp())) {
			
			// Step 2, add amount
			if (message.getResp().contains("Amount")) {
				message = addAmount(mobile, port, amount);
			}
			// Step 3, confirm M-pin
			if (message.getResp().contains("M-pin")) {
				message = confirmMPin(mobile, port);
			}
			// Step 4, confirm M-pin (optional)
			if (message.getResp().contains("M-pin")) {
				message = confirmMPin(mobile, port);
			}
		}
		return message;
	}
	
	public static Message preRequestTopup(String port, String mobile, String optionCode) throws InterruptedException, JSONException, IOException {
		String url = FTP_USSD_GATEWAY + "username=" + USER_NAME + "&password=" + PASSWORD + "&port=" + port
				+ "&ussd=*555*" + mobile + "*" + optionCode + "%23";

		log.info(mobile + " -> telenor eload topup prerequest : " + url);

		Message msg = new Message();
		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		ObjectMapper objectMapper = new ObjectMapper();
		msg = objectMapper.readValue(response.toString(), Message.class);
		
		log.info(mobile + " -> telenor eload topup prerequest response : " + msg.toString());
		return msg;
	}
	
	public static Message addAmount(String mobile, String port, String amount) throws InterruptedException, JSONException, IOException {

		String url = FTP_USSD_GATEWAY + "username=" + USER_NAME + "&password=" + PASSWORD + "&port=" + port
				+ "&ussd=" + amount;

		log.info(mobile + " -> telenor eload topup - add amount : " + url);

		Message msg = new Message();
		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		ObjectMapper objectMapper = new ObjectMapper();
		msg = objectMapper.readValue(response.toString(), Message.class);
		log.info(mobile + " -> telenor eload topup - add amount : " + msg.toString());
		return msg;
	}

	public static Message confirmMPin(String mobile, String port) throws InterruptedException, JSONException, IOException {
		String url = FTP_USSD_GATEWAY + "username=" + USER_NAME + "&password=" + PASSWORD + "&port=" + port + "&ussd=5678";
		
		log.info(mobile + " -> telenor eload confirm M-pin request : " + url);
		
		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		ObjectMapper objectMapper = new ObjectMapper();
		Message msg = objectMapper.readValue(response.toString(), Message.class);

		log.info(mobile + " -> telenor eload confirm M-pin response : " + msg.toString());
		return msg;
	}
}
