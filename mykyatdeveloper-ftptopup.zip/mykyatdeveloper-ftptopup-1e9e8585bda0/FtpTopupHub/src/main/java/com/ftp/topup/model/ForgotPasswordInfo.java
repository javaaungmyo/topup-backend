package com.ftp.topup.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "forgot_password_info")
public class ForgotPasswordInfo {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	
	@Column(name = "userid", unique = true, nullable = false)
	private String userid;

	@Column(name = "forgot_password", nullable = false)
	private int forgotPassword;
	
	@Column(name = "mobile", nullable = false)
	private String mobile;
	
	
	@Column(name = "created_by", nullable = false)
	private long createdBy;
	
	@Column(name = "created_date", nullable = false)
	private Date createdDate;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public int getForgotPassword() {
		return forgotPassword;
	}

	public void setForgotPassword(int forgotPassword) {
		this.forgotPassword = forgotPassword;
	}

	public long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}

	
	
}
