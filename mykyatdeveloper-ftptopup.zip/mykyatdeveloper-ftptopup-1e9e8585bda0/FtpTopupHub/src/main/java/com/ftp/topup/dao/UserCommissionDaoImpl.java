package com.ftp.topup.dao;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.ftp.topup.model.UserCommission;

@Repository("userCommissionDao")
public class UserCommissionDaoImpl extends AbstractDao<Integer, UserCommission> implements UserCommissionDao {

	public UserCommission findByUserId(long userId) {
		Criteria crit = createEntityCriteria();
		crit.add(Restrictions.eq("user.id", userId));
		UserCommission commission = (UserCommission) crit.uniqueResult();
		return commission;
	}

}
