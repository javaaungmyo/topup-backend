package com.ftp.topup.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ftp.topup.util.CommonUtils;

@RestController
public class SvaController {
	@PostMapping("/sva")
	public Map<String, Object> getSVA(@RequestParam("user_id") long userId) {
		Map<String, Object> results = new HashMap();
		long sva = CommonUtils.getSva(userId);
		results.put("sva", sva);
		return results;
	}
}
