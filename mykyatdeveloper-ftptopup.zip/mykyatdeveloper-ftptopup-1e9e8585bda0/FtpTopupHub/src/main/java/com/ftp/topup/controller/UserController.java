package com.ftp.topup.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ftp.topup.model.ResponseStatus;
import com.ftp.topup.model.User;
import com.ftp.topup.model.UserSva;
import com.ftp.topup.sms.SmsService;
import com.ftp.topup.util.GenerateTempPassword;

@RestController
public class UserController extends CommonController {

	private static final Log log = LogFactory.getLog(UserController.class);

	@PostMapping("/user/login")
	public Map<String, Object> login(@RequestParam("username") String username,
			@RequestParam("password") String password) {
		ResponseStatus status = null;
		Map<String, Object> results = new HashMap();
		User user = service.findByUsername(username);
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

		if (user == null) {
			status = new ResponseStatus(0, "User not found!");
		} else if (user.getStatus() == 0) {
			status = new ResponseStatus(0, "User blacklist!");
		} else {
			boolean u = encoder.matches(password, user.getPassword());
			if (u) {
				UserSva sva = svaService.findByUserId(user.getId());
				status = new ResponseStatus(1, "User found!");
				results.put("data", sva);
				log.info("login success!");
			} else {
				status = new ResponseStatus(0, "Wrong password!");
			}
		}

		results.put("status", status);
		return results;
	}

	@PostMapping("/user/change_password")
	public Map<String, Object> changePassowrd(@RequestParam("password") String password,
			@RequestParam("user_id") int userId, @RequestParam("currentpassword") String currentpassword) {
		ResponseStatus status = null;
		Map<String, Object> results = new HashMap();
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		String message= "You have changed myKyat Topup login password successfully. If you have any enquires, pls contact 09450374911,09450374912.Thank you for using myKyat.";
		String mobile = "";
		User user = new User();
			user = service.findById(userId);
		boolean u = encoder.matches(currentpassword, user.getPassword());
		mobile = user.getMobile();
		 if(u){
			 String pwd_message = checkIsPasswordStrong(password);
				
				if(pwd_message.equals("")) {
					try{
						SmsService.sendMessage(mobile, message);
					}catch (Exception e){
						e.printStackTrace();
						status = new ResponseStatus(0, "Send password error!");
					}
					service.updatePassword(encoder.encode(password), userId);
					status = new ResponseStatus(1, "Password change success!");
				}else
					status = new ResponseStatus(0, pwd_message);
		 }else
			 status = new ResponseStatus(0, "Current password is incorrect!");
			
		results.put("status", status);
		
		return results;
	}
	
	@PostMapping("/user/forgot_password")
	public Map<String, Object> forgotPassowrd(@RequestParam("mobile") String mobile) {
		ResponseStatus status = null;
		Map<String, Object> results = new HashMap();
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		String temp_pwd;
		String message;
		User user = service.findByMobile(mobile);
		if(user != null){
			
			temp_pwd = GenerateTempPassword.generateTemporaryPassword();
			message = "Your temporary password is "+temp_pwd+". Thanks for using MyKyat.";
			
			try {
				SmsService.sendMessage(mobile, message);
				service.updatePassword(mobile, encoder.encode(temp_pwd));
				//save temp password
				service.saveForgotPassword(mobile, temp_pwd);
				status = new ResponseStatus(1, "Password send success!");
			} catch (IOException e) {
				
				e.printStackTrace();
				status = new ResponseStatus(0, "Password send error!");
			}
			
		}
		else
			status = new ResponseStatus(0, "Your mobile number is not registered yet. Please try again!");
		
		//int updateStatus = service.updatePassword(mobile, encoder.encode(temp_pwd));
        
		/*if (updateStatus != 1) {
			status = new ResponseStatus(0, "Your mobile number is not registered yet. Please try again!");
		} else {
			status = new ResponseStatus(1, "Password change success!");
		}	*/	

		results.put("status", status);
		return results;
	}

	@PostMapping("/user/logout")
	public Map<String, Object> logout(HttpServletRequest request, HttpServletResponse response) {
		ResponseStatus status = null;
		Map<String, Object> results = new HashMap();
		status = new ResponseStatus(1, "Logout success!");
		results.put("status", status);
		return results;
	}
	
	
	public static String checkIsPasswordStrong(String password){
		String message = "";
		
		if(password.length()< 8)
			message= "Password must contain at least 8 characters !";
		else if(!password.matches("(?=.*[0-9]).*") || !password.matches("(?=.*[A-Z]).*") || !password.matches("(?=.*[a-z]).*") )
			message = "Password must contain uppercase, lowercase letters and numbers!";
		
		
		return message;
	}
	

}
